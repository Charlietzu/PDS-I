float parteInteira(float x);

float parteFracionaria(float x);

float divInts(int x, int y);