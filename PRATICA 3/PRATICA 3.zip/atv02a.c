#include <stdio.h>

int main() {
    int a;
    float b;
    char c;

    printf("Endereco de a: %p\n", &a);
    printf("Endereco de b: %p\n", &b);
    printf("Endereco de c: %p\n", &c);

    return 0;
}