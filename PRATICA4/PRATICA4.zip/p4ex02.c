#include <stdio.h>
#include "pratica4.h"

/*float areaCirculo (float raio){
	float pi = 3.141592;
	float a = pi * (raio * raio);
	return a;
}*/

int main(){
	printf("A area do circulo eh: %f\n", areaCirculo(4.0));
	
	return 0;
}
