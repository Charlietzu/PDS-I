#include <stdio.h>
#include "pratica4.h"
/*
float paraMetrosPorSegundo(float v){
	float m;
	return m = v / 3.6;
}
*/

int main(){
	printf("A velocidade em m/s e = %f\n", paraMetrosPorSegundo(60));
	return 0;
}
