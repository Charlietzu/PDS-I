//M�dulo das fun��es
float paraMetrosPorSegundo(float v);

float areaCirculo (float raio);

int ehPar(int n);

int ehDivisivelPor3ou5(int n);

float pesoIdeal(float h, char sexo);

int somaImpares(int N);

double fatorial(int N);

int somaNumerosDiv3ou5(int N);

float calculaMedia(int x, int y, int z, int operacao);

int numeroDivisores(int N);

int enesimoFibonacci(int N);

int mdc(unsigned int x, unsigned int y);

int mmc(unsigned int x, unsigned int y);
