#include <stdio.h>
#include "pratica4.h"

/*int ehDivisivelPor3ou5(int n){
	if ((n % 3 == 0 & n % 5 == 0) || (n % 3 != 0 & n % 5 != 0)){
		return 0;
	} else {
		return 1;
	}
}*/

int main(){
	printf("%i\n", ehDivisivelPor3ou5(5));
	
	return 0;
}
