#include <stdio.h>
#include "pratica4.h"

/*int ehPar(int n){
	if(n % 2 == 0 ){
		return 1;
	} else {
		return 0;
	}
}*/

int main(){
	printf("%i\n", ehPar(3));
	
	return 0;
}
