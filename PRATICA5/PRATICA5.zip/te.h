#include <stdio.h>

int ehPotencia2(int x);

void ordena(int *end_var1, int *end_var2);