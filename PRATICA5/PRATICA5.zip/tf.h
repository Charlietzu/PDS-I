#include <stdio.h>

int hotpo(unsigned int N);

int collatz(unsigned int N);

void leIntervalo(int *endmin, int *endmax);
